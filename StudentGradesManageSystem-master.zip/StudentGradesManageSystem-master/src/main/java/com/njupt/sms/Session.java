package com.njupt.sms;

/**
 * Created by jason on 9/2/15.
 */
public class Session {
    /**
     * 全局的用户信息,通过他可以判断是否登陆,以及当前的登陆身份
     */
    public static Object userInfo;


}
