package com.njupt.sms;


public class Session {
    /**
     * 全局的用户信息,通过他可以判断是否登陆,以及当前的登陆身份
     */
    public static Object userInfo;


}
